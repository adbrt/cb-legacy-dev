
#define SF_MOVEMENT         (0x0001U)
#define SF_B1_DOWN          (0x0002U)
#define SF_B1_UP            (0x0004U)
#define SF_B2_DOWN          (0x0008U)
#define SF_B2_UP            (0x0010U)
#define SF_ABSOLUTE         (0x8000U)

